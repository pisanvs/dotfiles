package utils

func MaxInt(a, b int) int {
	if a > b {
		return a
	}
	return b
}
